import React from "react";

export default function ContactUs({ title, dark, id }) {
  return (
    <div className={"section" + (dark ? " section-dark" : "")}>
      <div className="section-content" id={id}>
        <span className="aboutus_heading">{title}</span>
      </div>
    </div>
  );
}
