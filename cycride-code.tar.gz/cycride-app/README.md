# React With Smooth Scrolling

![React with Smooth Scrolling](./images/cover.png)

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## To Run

- clone this repository
- run `npm install`
- run `npm start`
